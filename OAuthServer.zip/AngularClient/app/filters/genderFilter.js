﻿"use strict";

define([], function () {

    var genderFilterObj = function () {

        return function (gender) {
            if (isNaN(gender)) {
                return '';
            }
            if (gender === true) {
                return "Male";
            }
            else if (gender === false) {
                return "Female";
            }
            else {
                throw "Inavlid gender parameter value.";
            }
        };

    }


    return genderFilterObj;

});