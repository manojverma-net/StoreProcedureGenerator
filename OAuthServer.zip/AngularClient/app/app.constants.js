﻿define([], function () {

	'use strict';

	var constantObj = function () {
		return {
			serviceUrl: 'http://localhost:51189/api/employee'
		};
	};

	return constantObj;

});

/*
Need to inject and use it.
*/