﻿
define([], function () {
    'use strict';

    var routeConfigObj = function ($stateProvider, $locationProvider, $urlRouterProvider) {
          
        $urlRouterProvider.otherwise('/error');

        $stateProvider.state('home',
                        {
                            url: '/',
                            controller: 'employeeController',
                            templateUrl: 'app/components/employee/views/home.html'
                        })
                        .state('addemployee',
                        {
                            url: '/add',
                            controller: 'employeeController',
                            templateUrl: 'app/components/employee/views/add.html'
                        })
                        .state('error', {
                            url: '/error',
                            controller: 'errorController',
                            templateUrl: 'app/components/error/views/404.html'
                        });

        $locationProvider.html5Mode(false);

    }

    routeConfigObj.$inject = ['$stateProvider', '$locationProvider', '$urlRouterProvider'];

    return routeConfigObj;

});