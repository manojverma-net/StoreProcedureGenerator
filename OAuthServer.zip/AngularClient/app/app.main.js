﻿
require.config({
    paths: {
        'angular': '../scripts/angular',
        'ngRoute': '../scripts/angular-route',
        'uiRoute': '../scripts/angular-ui-router',
        'ngTable': '../scripts/ngtable/ng-table.min',
        'datePicker': '../scripts/datepicker/angular-bootstrap-datepicker'

    },
    shim: {
        angular: {
            exports: "angular"
        },
        uiRoute: {
            deps: ["angular"],
            exports: "angular"
        },
        ngTable: {
            deps: ["angular"],
            exports: "angular"
        },
        datePicker: {
            deps: ["angular"],
            exports: "angular"
        }
    },
   baseUrl: '/app'
});
  
require(['app.module'], function (app) {
    app.init();
});