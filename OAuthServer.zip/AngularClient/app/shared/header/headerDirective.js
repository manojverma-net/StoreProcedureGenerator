﻿define([], function() { 
    "use strict";

    var headerDirective = function () {
        var directive = {};

        directive.restrict = 'E'; 
        directive.templateUrl = "../app/shared/header/header.html";

        directive.scope = {
            "projectTitle": "Employee Management App",
            "headerMenus": [
                            {
                                "href": "/",
                                "text": "Dashboard"
                            },
                            {
                                "href": "/",
                                "text": "Temp Link"
                            }]
        };

        //directive.compile = function (element, attributes) {
        //    element.css("border", "1px solid #cccccc");

        //    //linkFunction is linked with each element with scope to get the element specific data.
        //    var linkFunction = function ($scope, element, attributes) {
        //        //element.html("Student: <b>" + $scope.student.name + "</b> , Roll No: <b>" + $scope.student.rollno + "</b><br/>");
        //        element.css("background-color", "#ff00ff");
        //    }
        //    return linkFunction;
        //}


        return directive;
    };


   // headerDirective.$inject = ["$scope"];

    return headerDirective;

});