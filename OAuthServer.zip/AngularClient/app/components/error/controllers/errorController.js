﻿define([], function () {
    'use strict';

    var errorControllerObj = function ($scope) {
        
    }

    errorControllerObj.$inject = ['$scope'];

    return errorControllerObj;
});