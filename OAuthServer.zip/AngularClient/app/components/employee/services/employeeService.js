﻿define([], function () {

    var employeeServiceObj = function ($http, $q) {

        var _serviceUrl = 'http://localhost:51189/api/employee';

        function getEmployees() {
            return $http({
                method: 'GET',
                url: _serviceUrl
            });
        }

        function getEmployeeById(employeeId) {
            return $http({
                method: 'GET',
                url: _serviceUrl,
                data: { id: employeeId }
            });
        }

        function addEmployee(employee) {
            return $http({
                method: 'POST',
                url: _serviceUrl,
                data: {
                    name: employee.name,
                    age: employee.age,
                    gender: employee.gender,
                    dateOfBirth: employee.dob
                }
            });
        }

        function updateEmployee(employee) {
            return $http({
                method: 'PUT',
                url: _serviceUrl + '?id=' + employee.id,
                data: { 
                    name: employee.name,
                    age: employee.age,
                    gender: employee.gender,
                    dateOfBirth: employee.dob
                }
            });
        }

        function deleteEmployee(employeeId) {

           return  $http.delete(_serviceUrl + '?id=' + employeeId); 
        }


        return {
            add: addEmployee,
            update: updateEmployee,
            remove: deleteEmployee,
            get: getEmployeeById,
            getAll: getEmployees
        };
    }

    employeeServiceObj.$inject = ['$http', '$q'];

    return employeeServiceObj;

});