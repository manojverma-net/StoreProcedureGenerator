﻿
define([], function () {

    "use strict";

    var employeeControllerObj = function ($scope, employeeService, NgTableParams) {
        
        //=============[ data members ]====================

        //employee data members

        $scope.isEditMode = false;

        $scope.employee = {
            id: "",
            name: "",
            age: "",
            gender: true,
            dob: ""
        };

        //grid data members
        var initialParams = {
            count: 5     // initial page size
        };
         
        $scope.tableParams = new NgTableParams({}, {});
         

        //=============[ data methods ]====================

        $scope.init = function () {

            employeeService.getAll().then(function (response) {
                $scope.tableParams = new NgTableParams(initialParams, {
                    counts: [5, 10, 20],
                    paginationMaxBlocks: 5,
                    paginationMinBlocks: 2,
                    dataset: response.data.Response
                });

            }, function (error) {
                alert(error);
                console.log(error);
            });
        }
         
        $scope.addEmployee = function (isValid) {
            if (isValid) {
                employeeService.add($scope.employee).then(function () {
                    alert("saved successdully");
                }, function () {
                    alert("error");
                });
            }
        };

        $scope.deleteEmployee = function (employeeId) {
            employeeService.remove(employeeId).then(function (response) {
                alert("employee deleted!!");
                $scope.init();
            }, function (error) {
                alert(error);
                console.log(error);
            });
        }

        $scope.editEmployee = function (objEmployee) {

            $scope.isEditMode = true;

            $scope.employee.id = objEmployee.EmployeeId;
            $scope.employee.name = objEmployee.Name;
            $scope.employee.age = objEmployee.Age;
            $scope.employee.gender = objEmployee.Gender.toString();
            $scope.employee.dob = new Date(objEmployee.DateOfBirth);
        }

        $scope.updateEmployee = function (isValid) {
            if (isValid) {
                employeeService.update($scope.employee).then(function (response) {
                    angular.element('#myModal').modal('hide');
                    $scope.isEditMode = false;
                    $scope.init();
                },
                function (error) {
                    alert(error);
                    console.log(error);
                });
            }
        }
         

    }


    employeeControllerObj.$inject = ['$scope', 'employeeService', 'NgTableParams'];

    return employeeControllerObj;

});