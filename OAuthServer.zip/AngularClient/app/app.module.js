﻿
define(['angular', 'uiRoute', 'ngTable',
    'filters/genderFilter', 'app.routes', 'components/employee/services/employeeService', 'components/employee/controllers/employeeController',
    'components/error/controllers/errorController'],
function (angular, uiRoute, ngTable, genderFilter, routeConfig, employeeService, employeeCtrl, errorCtrl) {
    'use strict';

    var moduleObj = function () {

        angular.module("sampleApp", ["ui.router", "ngTable"])
           .controller('employeeController', employeeCtrl)
           .controller('errorController', errorCtrl)
           .service('employeeService', employeeService)
           .filter('gender', genderFilter)
           .config(routeConfig);

        //bootstraping angular application 
        angular.bootstrap(document, ['sampleApp']);
    }

    return { init: moduleObj };
});